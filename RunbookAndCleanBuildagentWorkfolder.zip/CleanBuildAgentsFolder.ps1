    Write-Output 'CleanBuildAgentFolder.ps working ..'

    $AgentWorkFolder = "c:\agent\_work\"

    if($AgentWorkFolder -eq $null){Throw("Variable 'AgentWorkFolder' is Null")}

    # create a temporary (empty) folder
    $parent = [System.IO.Path]::GetTempPath()
    [string] $tempName = "work_robocopy"
    $tempfolder = New-Item -ItemType Directory -Path (Join-Path $parent $tempName)

    robocopy /MIR $tempfolder.FullName $AgentWorkFolder | out-null
    Remove-Item $AgentWorkFolder -Force | out-null
    Remove-Item $tempfolder -Force | out-null

    . mkdir $AgentWorkFolder

    Write-Output 'All done ..'