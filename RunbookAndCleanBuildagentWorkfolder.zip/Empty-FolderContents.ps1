function Empty-FolderContents
{
    Param(
        [string]$folder
    )

    # create a temporary (empty) folder
    $parent = [System.IO.Path]::GetTempPath()
    [string] $tempName = "work_robocopy"
    $tempfolder = New-Item -ItemType Directory -Path (Join-Path $parent $tempName)

    robocopy /MIR $tempfolder.FullName $folder | out-null
    Remove-Item $folder -Force | out-null
    Remove-Item $tempfolder -Force | out-null
   
    . mkdir $folder
}