# Clear everything
Get-AzureRmContext | Remove-AzureRmContext -Force

# Login to an account
Login-AzureRmAccount -SubscriptionName "My Subscription"
Login-AzureRmAccount

# Show all subscriptions you got access to
Get-AzureRmSubscription

# Select subscription 
Select-AzureRmSubscription -Subscription xxxx

# Get/set your current context
Get-AzureRmContext
Set-AzureRmContext -Subscription x
Set-AzureRmContext -Subscription x -TenantId y

# Make every session default to the last context set with Set-AzureRmContext
Enable-AzureRmContextAutosave

# Show chosen subscription (in the current context)
(Get-AzureRmContext).Subscription
$subscrId = (Get-AzureRmContext).Subscription.Id

